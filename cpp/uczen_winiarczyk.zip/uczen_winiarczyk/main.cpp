#include <iostream>
#include "uczen.h"


using namespace std;

int main(int argc, char **argv)
{
    Uczen u1();
    cout << "Średnia ucznia: ";
    u1.srednia();
        
	return 0;
}
