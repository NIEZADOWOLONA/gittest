#include <iostream>
#include <string>
#include "uczen.h"

using namespace std;

Uczen::Uczen(string imie, string nazwisko){
	
}

void Uczen::srednia(int ){
    ;
}

void Uczen:ustaw_klase(string klasa){
	;
}
